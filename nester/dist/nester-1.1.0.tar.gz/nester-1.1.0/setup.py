from distutils.core import setup

setup(
    name='nester',
    version='1.1.0',
    py_modules=['nester'],
    author='lczean',
    author_email='lczean@163.com',
    url='https://github.com/lczean',
    description='A simple printer of nested lists',
)
